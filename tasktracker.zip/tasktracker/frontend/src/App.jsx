import React, { useState, useEffect } from 'react';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import DayPicker from './components/DayPicker';
import StatsChart from './components/StatsChart';
import ChartControls from './components/ChartControls';
import { getTasks, getSummary } from './api';

export default function App() {
  const [date, setDate] = useState(new Date().toISOString().slice(0,10));
  const [tasks, setTasks] = useState([]);
  const [mode, setMode] = useState('week');
  const [summary, setSummary] = useState([]);

  // UI state
  const [showAdd, setShowAdd] = useState(false);
  const [chartType, setChartType] = useState('bar'); // bar | line | scatter
  const [palette, setPalette] = useState('indigo'); // indigo | teal | orange | crimson

  async function loadTasks(d = date) {
    try {
      const res = await getTasks(d);
      setTasks(res);
    } catch (err) {
      console.error(err);
    }
  }

  async function loadSummary(m = mode) {
    try {
      const res = await getSummary(m);
      setSummary(res);
    } catch (err) {
      console.error(err);
    }
  }

  useEffect(() => { loadTasks(); }, [date]);
  useEffect(() => { loadSummary(); }, [mode, date]);

  return (
    <div className="min-h-screen p-6 md:p-10 bg-gradient-to-br from-white to-slate-50">
      <div className="max-w-7xl mx-auto">
        <header className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="rounded-xl header-gradient p-4 shadow-sm w-full md:max-w-2xl">
            <h1 className="text-3xl font-semibold tracking-tight">TaskTracker</h1>
            <p className="text-slate-600 mt-1">Beautiful, ordered daily tasks with interactive charts. Templates auto-populate each date.</p>
          </div>

          <div className="flex gap-3 items-center">
            <DayPicker date={date} setDate={setDate} />
            <select value={mode} onChange={e => setMode(e.target.value)} className="border rounded p-2 bg-white">
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="year">This Year</option>
            </select>
          </div>
        </header>

        <main className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left / Main — Tasks */}
          <section className="lg:col-span-2">
            <div className="card p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold">Tasks — {date}</h2>
                  <p className="text-sm text-slate-500">Morning tasks appear first. Tap ✓ to mark complete and rate.</p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setShowAdd(s => !s)}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 text-white shadow hover:bg-indigo-700"
                  >
                    {showAdd ? 'Close' : 'Add'}
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={showAdd ? "M6 18L18 6M6 6l12 12" : "M12 4v16m8-8H4"} /></svg>
                  </button>
                </div>
              </div>

              {/* Add form (hidden by default) */}
              <div className={`mt-4 transition-all ${showAdd ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}>
                {showAdd && <TaskForm onAdded={loadTasks} date={date} onClose={() => setShowAdd(false)} />}
              </div>

              <div className="mt-6">
                <TaskList tasks={tasks} onChange={loadTasks} date={date} />
              </div>
            </div>
          </section>

          {/* Right — Chart */}
          <aside className="card p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-lg">Progress</h3>
              <div className="text-sm text-slate-500">Mode: {mode}</div>
            </div>

            <ChartControls chartType={chartType} setChartType={setChartType} palette={palette} setPalette={setPalette} />

            <div className="mt-4">
              <StatsChart data={summary} chartType={chartType} palette={palette} />
            </div>
          </aside>
        </main>
      </div>
    </div>
  );
}
