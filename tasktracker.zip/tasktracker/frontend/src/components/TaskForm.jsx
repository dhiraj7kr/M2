import React, { useState } from 'react';
import { createTask } from '../api';

export default function TaskForm({ onAdded, date, onClose }) {
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [timeSlot, setTimeSlot] = useState('');
  const [saving, setSaving] = useState(false);

  const submit = async (e) => {
    e?.preventDefault();
    if (!title.trim()) return;
    setSaving(true);
    try {
      await createTask({ title: title.trim(), description: desc.trim(), date, time_slot: timeSlot.trim() });
      setTitle(''); setDesc(''); setTimeSlot('');
      onAdded && onAdded(date);
      onClose && onClose();
    } catch (err) {
      console.error(err);
      alert('Failed to add task');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
      <div className="">
        <label className="text-sm text-slate-600">Task</label>
        <input className="input w-full mt-1" placeholder="Task title" value={title} onChange={e => setTitle(e.target.value)} />
      </div>

      <div>
        <label className="text-sm text-slate-600">Time slot</label>
        <input className="input w-full mt-1" placeholder="e.g. 7:30 – 8:30 AM" value={timeSlot} onChange={e => setTimeSlot(e.target.value)} />
      </div>

      <div>
        <label className="text-sm text-slate-600">Description (optional)</label>
        <input className="input w-full mt-1" placeholder="Short description" value={desc} onChange={e => setDesc(e.target.value)} />
      </div>

      <div className="md:col-span-3 flex justify-end gap-3 mt-2">
        <button type="button" onClick={onClose} className="px-4 py-2 rounded border">Cancel</button>
        <button type="submit" disabled={saving} className="px-5 py-2 rounded bg-indigo-600 text-white shadow">
          {saving ? 'Adding...' : 'Add Task'}
        </button>
      </div>
    </form>
  );
}
