import React from 'react';

const palettes = {
  indigo: '#5b21b6',
  teal: '#0f766e',
  orange: '#ea580c',
  crimson: '#dc2626'
};

export default function ChartControls({ chartType, setChartType, palette, setPalette }) {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <label className="text-sm text-slate-600">Chart type</label>
        <select value={chartType} onChange={e => setChartType(e.target.value)} className="border rounded p-2 bg-white text-sm">
          <option value="bar">Bar</option>
          <option value="line">Line</option>
          <option value="scatter">Scatter</option>
        </select>

        <div className="ml-3 text-sm text-slate-600">Palette</div>
        <div className="flex gap-2 ml-1">
          {Object.keys(palettes).map(key => (
            <button
              key={key}
              onClick={() => setPalette(key)}
              className={`w-7 h-7 rounded-full border ${palette === key ? 'ring-2 ring-offset-2 ring-indigo-200' : ''}`}
              style={{ background: palettes[key] }}
              title={key}
            />
          ))}
        </div>
      </div>
      <div className="text-xs text-slate-500">Tip: mark tasks complete to see the completed counts reflected in the chart.</div>
    </div>
  );
}
