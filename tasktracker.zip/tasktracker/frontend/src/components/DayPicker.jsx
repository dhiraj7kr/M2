import React from 'react';

export default function DayPicker({ date, setDate }) {
  return (
    <input
      type="date"
      value={date}
      onChange={e => setDate(e.target.value)}
      className="border rounded p-2 bg-white"
    />
  );
}
