import React, { useState } from 'react';
import { updateTask, toggleTask, deleteTask } from '../api';

/**
 * Parse a time-slot like "7:30 – 8:30 AM" or "2:00 – 4:00 PM"
 * Returns minutes since midnight for the start time for sorting.
 * If parsing fails, returns large number so it ends up at bottom.
 */
function parseTimeSlotStart(ts) {
  if (!ts) return 24*60 + 1;
  const dash = ts.split('–')[0] || ts.split('-')[0] || ts;
  // get AM/PM from full string if present
  let ampm = null;
  const up = ts.toUpperCase();
  if (up.includes('AM')) ampm = 'AM';
  if (up.includes('PM')) ampm = 'PM';
  // clean and parse
  let part = dash.replace(/[^\d:]/g, '').trim();
  if (!part) return 24*60+1;
  const [hStr,mStr] = part.split(':');
  let h = Number(hStr || 0), m = Number(mStr || 0);
  if (isNaN(h)) return 24*60+1;
  if (ampm === 'PM' && h < 12) h += 12;
  if (ampm === 'AM' && h === 12) h = 0;
  return h*60 + (isNaN(m) ? 0 : m);
}

export default function TaskList({ tasks = [], onChange, date }) {
  const [editingId, setEditingId] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editTime, setEditTime] = useState('');

  // sort by parsed time slot, fallback to created_at
  const sorted = [...tasks].sort((a,b) => {
    const ta = parseTimeSlotStart(a.time_slot);
    const tb = parseTimeSlotStart(b.time_slot);
    if (ta !== tb) return ta - tb;
    // fallback
    const da = new Date(a.created_at || 0).getTime();
    const db = new Date(b.created_at || 0).getTime();
    return da - db;
  });

  async function startEdit(t) {
    setEditingId(t.id); setEditTitle(t.title); setEditDesc(t.description || ''); setEditTime(t.time_slot || '');
  }
  async function saveEdit(id) {
    await updateTask(id, { title: editTitle, description: editDesc, time_slot: editTime });
    setEditingId(null);
    onChange && onChange(date);
  }
  async function toggle(id, completed) {
    let rating = null;
    if (!completed) {
      const r = prompt('Rate your completion (1-10) — optional', '8');
      rating = r ? Math.max(1, Math.min(10, Number(r))) : null;
    }
    await toggleTask(id, rating);
    onChange && onChange(date);
  }
  async function remove(id) {
    if (!confirm('Delete this task?')) return;
    await deleteTask(id);
    onChange && onChange(date);
  }

  return (
    <div>
      {sorted.length === 0 && <div className="text-slate-500 p-4">No tasks for this day.</div>}
      <ul className="space-y-3">
        {sorted.map(t => (
          <li key={t.id} className="flex items-start justify-between border rounded-lg p-3 bg-white">
            <div className="flex items-start gap-4">
              <button
                onClick={() => toggle(t.id, t.completed)}
                className={`w-11 h-11 rounded-full border flex items-center justify-center ${t.completed ? 'bg-emerald-500 text-white' : 'bg-white'}`}
                title={t.completed ? 'Mark incomplete' : 'Mark complete'}
              >
                ✓
              </button>

              <div>
                <div className="flex items-center gap-4">
                  <div className="task-time small-muted">{t.time_slot || '—'}</div>
                  {editingId === t.id ? (
                    <input className="border rounded p-1 text-lg" value={editTitle} onChange={e=>setEditTitle(e.target.value)} />
                  ) : (
                    <div className={`task-title ${t.completed ? 'line-through text-slate-400' : ''}`}>{t.title}</div>
                  )}
                </div>

                {editingId === t.id ? (
                  <>
                    <input className="border rounded p-1 mt-2 w-full" value={editDesc} onChange={e=>setEditDesc(e.target.value)} placeholder="Description" />
                    <input className="border rounded p-1 mt-2 w-44" value={editTime} onChange={e=>setEditTime(e.target.value)} placeholder="Time slot" />
                  </>
                ) : (
                  <>
                    {t.description && <div className="text-sm text-slate-600 mt-1">{t.description}</div>}
                    <div className="text-xs text-slate-400 mt-2">Rating: {t.rating ?? '-'} • Date: {t.date}</div>
                  </>
                )}
              </div>
            </div>

            <div className="flex gap-3 items-start">
              {editingId === t.id ? (
                <>
                  <button className="text-sm text-emerald-600" onClick={()=>saveEdit(t.id)}>Save</button>
                  <button className="text-sm text-slate-600" onClick={()=>setEditingId(null)}>Cancel</button>
                </>
              ) : (
                <>
                  <button className="text-sm text-sky-600" onClick={()=>startEdit(t)}>Edit</button>
                  <button className="text-sm text-rose-600" onClick={()=>remove(t.id)}>Delete</button>
                </>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
