import React from 'react';
import {
  ResponsiveContainer,
  BarChart, Bar,
  LineChart, Line,
  ScatterChart, Scatter,
  XAxis, YAxis, Tooltip, CartesianGrid
} from 'recharts';

// palette map
const palettes = {
  indigo: '#5b21b6',
  teal: '#0f766e',
  orange: '#ea580c',
  crimson: '#dc2626'
};

export default function StatsChart({ data = [], chartType = 'bar', palette = 'indigo' }) {
  // convert incoming summary to chart-friendly
  const chartData = data.map(d => ({
    date: d.date,
    completed: d.tasksCompleted ? Number(d.tasksCompleted) : 0,
    avgRating: d.avgRating ? Math.round(Number(d.avgRating) * 10) / 10 : 0
  }));

  if (!chartData.length) {
    return <div className="text-slate-500">No stats yet — complete tasks to see charts.</div>
  }

  const color = palettes[palette] || palettes.indigo;

  return (
    <div style={{ width: '100%', height: 340 }}>
      <ResponsiveContainer>
        {chartType === 'bar' && (
          <BarChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="completed" fill={color} radius={[6,6,0,0]} />
          </BarChart>
        )}

        {chartType === 'line' && (
          <LineChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="completed" stroke={color} strokeWidth={3} dot={{ r: 4 }} />
          </LineChart>
        )}

        {chartType === 'scatter' && (
          <ScatterChart margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" type="category" />
            <YAxis />
            <Tooltip />
            <Scatter name="Completed" data={chartData.map(d => ({ x: d.date, y: d.completed }))} fill={color} />
          </ScatterChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}
