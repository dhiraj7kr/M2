import axios from 'axios';
const BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000';

export async function getTasks(date) {
  return axios.get(`${BASE}/api/tasks`, { params: { date } }).then(r => r.data);
}
export async function createTask(payload) {
  return axios.post(`${BASE}/api/tasks`, payload).then(r => r.data);
}
export async function updateTask(id, payload) {
  return axios.put(`${BASE}/api/tasks/${id}`, payload).then(r => r.data);
}
export async function toggleTask(id, rating) {
  return axios.post(`${BASE}/api/tasks/${id}/toggle`, { rating }).then(r => r.data);
}
export async function deleteTask(id) {
  return axios.delete(`${BASE}/api/tasks/${id}`).then(r => r.data);
}
export async function getDailyStats(start, end) {
  return axios.get(`${BASE}/api/stats/daily`, { params: { start, end } }).then(r => r.data);
}
export async function getSummary(mode, start, end) {
  return axios.get(`${BASE}/api/stats/summary`, { params: { mode, start, end } }).then(r => r.data);
}
