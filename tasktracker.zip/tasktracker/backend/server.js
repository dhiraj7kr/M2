const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Utility
function isoDateOnly(d) {
  const dt = d ? new Date(d) : new Date();
  if (isNaN(dt)) return new Date().toISOString().slice(0,10);
  return dt.toISOString().slice(0,10);
}

function weekdayFromIso(dateIso) {
  const d = new Date(dateIso);
  // getDay(): 0 Sun .. 6 Sat
  const dow = d.getDay();
  if (dow >= 1 && dow <= 5) return 'mon-fri';
  return 'sat-sun';
}

// Seed tasks for a date from templates if none exist
function ensureTasksForDate(dateIso) {
  const count = db.prepare('SELECT COUNT(*) AS c FROM tasks WHERE date = ?').get(dateIso).c;
  if (count > 0) return; // already have tasks
  const recurrence = weekdayFromIso(dateIso);
  const templates = db.prepare('SELECT * FROM templates WHERE recurrence = ? ORDER BY id').all(recurrence);
  const insert = db.prepare('INSERT INTO tasks (title, description, time_slot, date) VALUES (?, ?, ?, ?)');
  const insertMany = db.transaction((rows) => {
    for (const r of rows) insert.run(r.title, '', r.time_slot, dateIso);
  });
  insertMany(templates);
}

// CRUD endpoints

// Create task
app.post('/api/tasks', (req, res) => {
  const { title, description = '', date, time_slot = '' } = req.body;
  if (!title || !date) return res.status(400).json({ error: 'title and date required' });
  const stmt = db.prepare(`INSERT INTO tasks (title, description, time_slot, date) VALUES (?, ?, ?, ?)`);
  const info = stmt.run(title, description, time_slot, isoDateOnly(date));
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(info.lastInsertRowid);
  res.json(task);
});

// Read tasks by date (auto-seed from template if needed)
app.get('/api/tasks', (req, res) => {
  const date = req.query.date ? isoDateOnly(req.query.date) : isoDateOnly();
  ensureTasksForDate(date);
  const rows = db.prepare('SELECT * FROM tasks WHERE date = ? ORDER BY time_slot, created_at DESC').all(date);
  res.json(rows);
});

// Read single task
app.get('/api/tasks/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'not found' });
  res.json(row);
});

// Update task (title, description, date, time_slot)
app.put('/api/tasks/:id', (req, res) => {
  const { title, description, date, time_slot } = req.body;
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'not found' });
  const stmt = db.prepare(`UPDATE tasks SET title = ?, description = ?, date = ?, time_slot = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`);
  stmt.run(title || task.title, description || task.description, date ? isoDateOnly(date) : task.date, time_slot ?? task.time_slot, req.params.id);
  const updated = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  res.json(updated);
});

// Toggle complete and optionally set rating (1-10)
app.post('/api/tasks/:id/toggle', (req, res) => {
  const { rating } = req.body; // optional when marking complete
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'not found' });
  const newCompleted = task.completed ? 0 : 1;
  const newRating = newCompleted && rating ? Math.max(1, Math.min(10, rating)) : (newCompleted ? task.rating : null);
  const stmt = db.prepare(`UPDATE tasks SET completed = ?, rating = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`);
  stmt.run(newCompleted, newRating, req.params.id);
  const updated = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  res.json(updated);
});

// Delete
app.delete('/api/tasks/:id', (req, res) => {
  const stmt = db.prepare('DELETE FROM tasks WHERE id = ?');
  const info = stmt.run(req.params.id);
  res.json({ deleted: info.changes });
});

// Aggregation endpoints (unchanged; daily and summary)
app.get('/api/stats/daily', (req, res) => {
  const start = req.query.start || isoDateOnly();
  const end = req.query.end || start;
  const stmt = db.prepare(`
    SELECT date,
           COUNT(*) AS totalTasks,
           SUM(completed) AS tasksCompleted,
           AVG(CASE WHEN rating IS NOT NULL THEN rating END) AS avgRating
    FROM tasks
    WHERE date BETWEEN ? AND ?
    GROUP BY date
    ORDER BY date
  `);
  const rows = stmt.all(start, end);
  res.json(rows);
});

app.get('/api/stats/summary', (req, res) => {
  const mode = req.query.mode || 'week';
  const start = req.query.start;
  const end = req.query.end;
  if (start && end) {
    const stmt = db.prepare(`
      SELECT date,
             COUNT(*) AS totalTasks,
             SUM(completed) AS tasksCompleted,
             AVG(CASE WHEN rating IS NOT NULL THEN rating END) AS avgRating
      FROM tasks
      WHERE date BETWEEN ? AND ?
      GROUP BY date ORDER BY date
    `);
    return res.json(stmt.all(start, end));
  }

  let from;
  const today = new Date();
  if (mode === 'week') {
    const d = new Date(today);
    const day = d.getDay(); // 0..6
    d.setDate(d.getDate() - day); // start Sunday
    from = d.toISOString().slice(0,10);
  } else if (mode === 'month') {
    const d = new Date(today.getFullYear(), today.getMonth(), 1);
    from = d.toISOString().slice(0,10);
  } else if (mode === 'year') {
    const d = new Date(today.getFullYear(), 0, 1);
    from = d.toISOString().slice(0,10);
  } else {
    from = isoDateOnly();
  }
  const stmt = db.prepare(`
    SELECT date,
           COUNT(*) AS totalTasks,
           SUM(completed) AS tasksCompleted,
           AVG(CASE WHEN rating IS NOT NULL THEN rating END) AS avgRating
    FROM tasks
    WHERE date BETWEEN ? AND ?
    GROUP BY date ORDER BY date
  `);
  const rows = stmt.all(from, isoDateOnly());
  res.json(rows);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`TaskTracker backend listening on ${PORT}`);
});
