// db.js - sqlite helper using better-sqlite3
const Database = require('better-sqlite3');
const path = require('path');
const db = new Database(path.join(__dirname, 'db.sqlite3'));

// initialize tables if not exists
const initSql = `
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  time_slot TEXT,            -- e.g. "7:30 – 8:30 AM"
  date TEXT NOT NULL,        -- ISO yyyy-mm-dd
  completed INTEGER DEFAULT 0,
  rating INTEGER DEFAULT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  time_slot TEXT,
  recurrence TEXT NOT NULL   -- 'mon-fri' or 'sat-sun'
);
`;
db.exec(initSql);

// Seed templates if empty
const count = db.prepare('SELECT COUNT(*) AS c FROM templates').get().c;
if (count === 0) {
  const insert = db.prepare('INSERT INTO templates (title, time_slot, recurrence) VALUES (?, ?, ?)');
  const monFri = [
    ['C# Training', '7:30 – 8:30 AM'],
    ['Job Applications', '8:30 – 9:00 AM'],
    ['German Learning', '9:00 – 10:00 AM'],
    ['DSA Preparation', '10:00 – 11:30 AM'],
    ['GATE Preparation', '11:30 – 1:00 PM'],
    ['Lunch/Break', '1:00 – 1:30 PM'],
    ['Office Work', '2:00 – 8:00 PM'],
    ['GATE/DSA Revision', '8:00 – 8:45 PM'],
    ['German Practice', '8:45 – 9:15 PM'],
    ['C#/Skill Wrap-Up', '9:15 – 10:00 PM']
  ];
  const satSun = [
    ['C# Training', '7:30 – 8:30 AM'],
    ['Job Applications', '8:30 – 9:30 AM'],
    ['German Intensive Study', '9:30 – 11:00 AM'],
    ['GATE Mock Test/Review', '11:00 – 1:30 PM'],
    ['Lunch/Break', '1:30 – 2:00 PM'],
    ['DSA Deep Practice', '2:00 – 4:00 PM'],
    ['German Real-world Use', '4:00 – 5:00 PM'],
    ['GATE Quick Revision', '5:00 – 6:00 PM'],
    ['C#/Skill Wrap-Up', '6:00 – 7:00 PM'],
    ['Relax/Hobbies', '7:00 – 9:00 PM']
  ];

  for (const t of monFri) insert.run(t[0], t[1], 'mon-fri');
  for (const t of satSun) insert.run(t[0], t[1], 'sat-sun');
}

module.exports = db;
